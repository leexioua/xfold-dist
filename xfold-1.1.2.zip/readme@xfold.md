# 软件说明 \<xfold\>
## 设计背景
- 解决需要经常执行的操作场景，折叠节省重复操作的时间
- 名字取自于编写时的初衷： 折叠时间 <=> ten-fold（十倍效率）
- 主要为自用，配置热键偏复杂，另相关动作可能存在需要编码扩展，使用门槛偏高

## 主要创新
- 扩展 LButton+e 操作平面， 按住LButton 击键e，鼠标划词或选择后操作较便捷
	+ Tips: 按住ESC+e <==> LButton+e (不足：当操作的窗口按Esc触发关闭情况 仍需要使用LButton+e)
- 单键，双键，三键，长按热键平面 丰富可定义更多的热键，
- 运行参数的设计 {%p} {%c} {%x}

## 主要功能
- 英语查词 LButton+e
- 快捷Everything查找文件 LButton+f
- 文本打开编辑 LButton+a
- 快速打开 LButton+r
- Welink发消息 LButton+w
- W3查询人员信息 LButton+3/LButton+w w
- 复制窗口标题及选择内容 LButton+t / LButton+t t / LButton+t t t
- 笔记收藏 LButton+s
- 资源管理器中保存剪贴板内容为文件 LButton+Ctrl+v
- 文件打开保存对话框跳转到当前资源管理器活动的目录 Ctrl+Q
- 常用搜索
    - Google: LButton+g
    - Baidu: LButton+b
    - Zhihu: LButton+z
    - Douban: LButton+d
## 快捷键速查
- xfold-shortcuts.xlsx
- xfold-shortcuts-default.pdf
- xfold-shortcuts-leexioua.pdf

## 环境准备依赖
- 软件运行环境
	+ 必备：AutoHotkey.exe
	+ 推荐：sublime_text.exe
	+ 推荐：Everything
	+ 推荐：英语词典 eudic
	+ 可选：西语助手 eshelper
	+ 可选：ALTRun
	+ 可选：MouseInc
	+ 可选：CapsLock+
	+ 可选：QTTabBar
	+ 可选：welink/w3
	+ 可选：FileLocator
	+ 可选：Active Desktop Calender
	+ 可选：Seer
	+ 以上推荐及可选软件，为本人个人使用，自用脚本调用
- 个人自用脚本参考
	+ 打发包存于 cmds\cmds-by-leexioua.zip
	+ D:\Links\ahk-cmd.ahk
	+ D:\Links\ahk\xfold\xfold-cmd.ahk
	+ D:\Links\ahk\xfold\xfold.ahk
	+ D:\Links\collect-cmd-v2.bat
	+ D:\Links\evernote\evernote-cmd.ahk
	+ D:\Links\evernote\evernote-cmds.bat
	+ D:\Links\everything\everything-cmd.ahk
	+ D:\Links\everything\everything-cmds.bat
	+ D:\Links\filelocator\locator-cmd.ahk
	+ D:\Links\settings-bak\UserData\matebook\bak-config-cmd.bat
	+ D:\Links\work-x1\mail-cmd.ahk
	+ 更多：xfold.ini - Cmd_xxx
- 系统环境变量
	+ Path=%Path%;D:\ProgramxFiles\AutoHotkey\AutoHotkey.exe
- 更多 >> 软件配置项：xfold.ini

## 热键映射配置说明
- 默认热键映射配置文件 keys-default.txt 如需更改为其它文件名称，可在 xfold.ini - [settings] - keymappings 中修改
- 参考配置示例增加修改即可，映射包括热键及动作两部分
	+ 如 ^m => SafeActivate(%eudic%) 中
		* ^m 为热键， SafeActivate(%eudic%) 为动作
	+ 同一个键被多次定义时，只使用最后一个定义，不会触发多个动作。
		* 如需要触发多个动作，动作列表可使用 ; 分隔进行定义
### 热键定义
- 热键修饰符
	+ \# => Win 、 ^ => Ctrl 、 ! => Alt 、 \+ => Shift
	+ 例： ^m => Ctrl+M  #f => Win+F
- 传统组合键
	+ 单键 single-press
		```js
		^m => SafeActivate(%eudic%)
		```
	+ 双键 double-press
		```js
		^q ^q => send(!{F4})
		```
	+ 三键 treble-press
		```js
		$F1 $F1 $F1 => open(notepad.exe)
		; 此处按键F1前的$ 为避免多键热键的自我触发
		```
	+ 长按 holding-press
		```js
		重复四次及以上视作长按
		$F1 $F1 $F1 $F1 => alert('holding-pressed F1')
		```
	+ LButton+组合键
		```js
		LButton+a => edit
		LButton+g => open(https://www.google.com/search?q={%x})
		LButton+e e => open(https://youglish.com/pronounce/{%x}/english?)
		LButton+t t t => copyWinTitle
		LButton+t t t t => title
		```

- 全局与特定应用生效
	+ 热键后跟 @应用进程名称 例： /@SumatraPDF.exe
		```js
		/@SumatraPDF.exe => open(%Help_SumatraPDF%)
		$F8 $F8@sublime_text.exe => srcAhkSearch
		```
### 动作定义
- 内置动作
	```js
	^(\w+)\(.*\)
	参考：keys-default.txt
	示例：
	open(notepad)
	```
	
	```js
	edit(filename)
	preview(filename)
	open(cmd, param := "")
	run(cmd, param := "")
	title(removeTail := true)
	process()
	reload()
	send(keys, delay := 0) 
	value(key, val := "")
	saveNotes(text := "")
	sleep(delay)
	info(message, args*)
	alert(str, args*)
	
	SafeActivate(program, activate:=True, miniWhenActive := False)
	alertLastCmd()
	redo()
	winMinimize()
	winTopToggle()
	winTransplus(w := 0)
	winTransMinus(w := 0)
	plainPaste()
	copyWinTitle()
	copyTitleTextLine()
	copyTitleText(singleline := 0)
	altTabSwitch()
	```
- 动作参数
	+ open()
	+ open("C:\Windows")
- 变量支持
	+ 环境变量
		* 例： %appdata% %temp%
	+ AHK运行环境变量
		* 例： %A_ScriptDir% %clipboard%
	+ 配置文件变量
		* xfold.ini中[Setting]定义的配置项 **优先**
		* xfold.ini中[Setting-default]定义的配置项
		* 例： %Everything%  %eudic%
	+ 特殊变量
		* {%c} 剪贴板内容
			- 等同 %clipboard%
			- {c} 等同 {%c}
				```js
				LButton+g => open(https://www.google.com/search?q={%c}
				```
		* {%p} 用户输入
			- 弹出对话框让用户输入
			- {p} {%q} {q} 等同 {%p}
				```js
				LButton+g => open(https://www.google.com/search?q={%p}
				```
		* {%x} 发送Ctrl+C临时复制
			- 执行时发送Ctrl+C复制获取的文本内容
			- {x} 等同 {%x}
				```js
				LButton+g => open(https://www.google.com/search?q={%x}
				```
- 多个动作
	+ ; 分隔多个动作
		```js
		LButton+c c c c => send(^c);info(has been copied.)
		```
### 配置文件 @xfold.ini
- 用户存储配置项信息，修改后需要重新启动脚本才生效
- [Setting-default] 下定义默认的配置项
- [Setting] 下定义用户配置项 *优先* 获取 [Setting] 下对应配置项，如未找到查找获取 [Setting-default] 下对应配置项
- [Constants] 下定义常量，可被[Setting] [Setting-default] 引用
	```js
	[Constants]
	ProgramxFiles=D:\ProgramxFiles
	MyLinks=D:\Links

	[Settings-default]
	editor=notepad.exe
	Help_keymappings=%A_ScriptDir%\leexioua-keys-default.ahk
	Link_notes=%A_ScriptDir%\#notes-list@ahk.md

	[Settings]
	editor=%ProgramxFiles%\SublimeText\sublime_text.exe
	```
### 默认样例参考
- %A_ScriptDir%\keys-default.txt
	```js
	; 配置请参考 readme@xfold.pdf
	; 配置修改需要重启xfold生效， 内置热键 Ctrl+Alt+R ，或映射自己的热键
	^!r => reload
	; $F5 $F5 => reload


	#= => winTransplus
	#- => winTransMinus
	^q ^q => send(!{F4})
	^+v => plainPaste
	$F4 $F4 => redo
	$F12 $F12 => alertLastCmd
	!e@explorer.exe => edit({%x})


	LButton+Space => send({Enter})
	LButton+LAlt => send({Delete})
	LButton+Tab => send(!{Tab})
	noReleasingLBtnAfterAction("Space")
	noReleasingLBtnAfterAction("LAlt")
	noReleasingLBtnAfterAction("Tab")

	; LButton+c c c c => send(^c);info(has been copied.)
	; LButton+v v v v => send(^v);info(has been pasted.)
	; LButton+x x x x => send(^x);info(has been cut.)
	; LButton+z z z z => send(^z);info(has been re-done.)
	; noReleasingLBtnAfterAction("c")
	; noReleasingLBtnAfterAction("v")
	; noReleasingLBtnAfterAction("x")
	; noReleasingLBtnAfterAction("z")

	LButton+1 1 => edit(%A_ScriptDir%\keys-default.txt)

	LButton+$F12 => winTopToggle
	LButton+^c => stripCopy
	LButton+, => open(https://youglish.com/pronounce/{%x}/english?)
	LButton+. => open(https://youglish.com/pronounce/{%x}/spanish?)

	LButton+a => edit
	LButton+b => open(https://www.baidu.com/s?wd={%x})
	LButton+b b => open(https://search.bilibili.com/all?keyword={%x})
	LButton+d => open(https://www.douban.com/search?q={%x})
	LButton+e => open(https://youdao.com/result?word={%x}&lang=en)
	LButton+e e => open(https://youglish.com/pronounce/{%x}/english?)
	LButton+f => findIt({%x})
	LButton+f f f f => finditByEverythingFullPath({%x})

	LButton+g => open(https://www.google.com/search?q={%x})

	LButton+p p p p => process
	LButton+r => open({%x})
	LButton+s => saveNotes
	LButton+t => copyTitleTextLine
	LButton+t t => copyTitleText
	LButton+t t t => copyWinTitle
	LButton+t t t t => title
	LButton+v => preview({%x})
	LButton+y => open(https://www.youtube.com/results?search_query={%x})
	LButton+z => open(https://www.zhihu.com/search?type=content&q={%x})

	; LButton+r r r r => run({%p})


	; work plugin
	#^!+f => work_outlookActivate
	LButton+w => work_welinkMsg
	LButton+w w => work_w3Info
	LButton+3 => work_w3Info
	LButton+m => work_findMail

	; explorer plugin
	; 文件对话框跳转到当前资源管理器活动的目录
	explorer_dialogueJump(~^q)
	; 资源管理器窗口功能
	LButton+Esc Esc Esc Esc@explorer.exe => explorer_closeOtherTabs
	LButton+^v@explorer.exe => explorer_clipboardSave2Txt
	; 切换查看视图
	LButton+1@explorer.exe => send(^!1)
	LButton+2@explorer.exe => send(^!2)
	LButton+3@explorer.exe => send(^!3)
	LButton+4@explorer.exe => send(^!4)
	LButton+5@explorer.exe => send(^!5)
	LButton+6@explorer.exe => send(^!6)
	LButton+7@explorer.exe => send(^!7)
	LButton+8@explorer.exe => send(^!8)
	noReleasingLBtnAfterAction(1@explorer.exe)
	noReleasingLBtnAfterAction(2@explorer.exe)
	noReleasingLBtnAfterAction(3@explorer.exe)
	noReleasingLBtnAfterAction(4@explorer.exe)
	noReleasingLBtnAfterAction(5@explorer.exe)
	noReleasingLBtnAfterAction(6@explorer.exe)
	noReleasingLBtnAfterAction(7@explorer.exe)
	noReleasingLBtnAfterAction(8@explorer.exe)


	; 以下为部分测试用例
	; ^F11 => eshelper
	; LButton+x => open(https://wyagd001.github.io/zh-cn/docs)
	; LButton+/ / / => copyTitleTextSingleline
	; LButton+1 1 => copyTitleTextSingleline
	; LButton+e e => eshelperQuery
	; LButton+f f f => eudicQuery
	; LButton+r r@sublime_text.exe => findIt
	; LButton+r r@notepad.exe => alert(123)
	; 1 1 => SafeActivate(%eudic%)
	; 1 1 => open(notepad)
	; $^o $^o => SafeActivate(%eudic%)
	; /@SumatraPDF.exe => open(%Help_SumatraPDF%)
	; r r@notepad.exe => alert(123);info(1334);alert(333)
	; LButton+Space => send({Enter})
	; LButton+n n n n => open(notepad)
	; LButton+n n n n => alert({%p})
	; LButton+n n n n"] => open(%SublimeText% {%p}, d:\text.txt)
	; LButton+n n n n"] => open(%SublimeText%, d:\text.txt)
	; $F1 $F1 $F1 => ahkCmd2AltRun
	; $F3 $F3 $F3 => everythingTerms2AltRun
	; LButton+w => value(hwid, {%x});open(notepad);send({raw}%hwid%, 200)
	```
	
# 更新日志
## 遗留优化 TODO
- 自动化测试/用例
- 代码走读 整理优化 增加打印日志，异常处理
- Send发送前进行检查，如未找到窗口取消发送文本
- plugin-adc plugin-excel 不同电脑 path/name 存在差异，需要检查修复
- 与CapsLocks+冲突问题，如 CapsLock+F1
- funcCmd 支持嵌套使用 例：alert(title())
- 解析热键定义中的保留字符使用 ; , 例： LButton+3 => copy;info("done;") 例： LButton+w => value(hwid, {%x});open(notepad);send({Text}%hwid%, 2000) 当hwid中包含保留字符,时
- hotstring功能支持配置
- 把包后支持自定义脚本扩展功能
- 增加组合键扩展 LButton+a e / Ctrl+k,Ctrl+d
- 迁移到Autohotkey2.0

## 20230413: 1.1.2
+ 增加 value(key, val) 提供保存用户变量，以便后期使用。 例： LButton+w => value(hwid, {%x});open(notepad);send({Text}%hwid%, 2000)
* 修正 F8长按失效问题  用例：$F8 $F8 $F8 $F8 => open(autohotkey.exe D:\Links\filelocator\locator-cmd.ahk {%p})
* 修正 资源管理器中保存剪贴板内容不信赖标题显示完整路径设置 @explorer_clipboardSave2Txt
* 增强 在资源管理器中 Alt+e 文本编辑选中文件 例： !e@explorer.exe => edit({%x})

## 20230409: 1.1.1
+ 通过配置文件定义热键绑定，方便后续 ahk2exe 打包可执行文件发布。 
    * 默认热键映射配置文件 keys-default.txt 如需更改为其它文件名称，可在 xfold.ini - [settings] - keymappings 中修改

## 20230408: 1.1.0
+ 项目取名 xfold ， 修改相关文件及目录命名，xfold初始版本为1.1.0
+ 增加配置文件常量定义，变量值中支持嵌套变量
```js
[Constants]
ProgramxFiles=D:\ProgramxFiles
[Settings]
editor=%ProgramxFiles%\SublimeText\sublime_text.exe
```
+ 增加回做最近一次动作 redo ，类似excel F4功能。 热键: F4 F4 => redo , F12 F12 F12 F12 => alertLastCmd
+ ahk脚本实现收集保存内容功能 saveNotes 。 LButton+s => saveNotes
+ open 动作支持快速打开注册表路径 依赖 regjump.bat 例：open(HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Applets\Regedit)
+ 个人自用脚本打包供参考 cmds\cmds-by-leexioua.zip
* 修复Esc存在多次发送问题 @xfold-init-keybinding.ahk
* 调整应用框架代码，重命名，目录位置
* 修改命名 holdLBtnAfterAction => noReleasingLBtnAfterAction


## 20230330: 1.0.11
+ 整理简化不必要的动作方法 @leexioua-actions.ahk
+ 增强funcCmd支持ahk系统变量 例 %A_ScriptDir%
+ 增加 LButton+c => Ctrl+c, LButton+x => Ctrl+x, LButton+v => Ctrl+v, LButton+z => Ctrl+z
+ 支持默认及用户键映射定义扩展 例 @leexioua-keys-default.ahk @leexioua-keys-sean.ahk
* 整理默认通用键映射配置 减少依赖 @leexioua-keys-default.ahk
* 修改自用键映射配置文件命名 @leexioua-keys-sean.ahk 
* 优化 open 动作，打开网页时参数拼接，参数前不补空格 open("https://www.google.com/search?q=","{%x}")
* 优化 open 动作，捕获运行异常并提示用户
* 修改配置文件编码为UTF-16 @leexioua-ahk.ini
* 整理脚本入口，分离基础与个性化的功能，以便后续使用用户自主选择或扩展增强功能 @leexioua-ahk.ahk
* 优化 stripLine , 增加 # ; 等引导符剥除
* 优化增加默认参数 \[Setting-default\] @leexioua-settings.ahk

## 20230324: 1.0.10
+ open(cmd)/funcCmd(cmd) 增加支持临时复制选择文本的参数 {%x}
+ 增加 title(removeTail:=True) ，获取当前窗口的标题到剪贴板
+ 增加 process ，获取当前窗口的进展名到剪贴板
+ 增加 LButton+r长按 => run({%p})，支持运行内置的动作
+ 增加 plugin-markdown.ahk 支持将剪贴板图片/图片路径，复制成markdown DataURI形式 !\[pic\](data:image/png;base64,xxx)
* 修正funcCmd(cmd) {%p}参数不生效问题
* open 增加别名 run ，open(notepad) <==> run(notepad)
* 修改命名 holdingLBtnAfterAction => holdLBtnAfterAction

## 20230318: 1.0.9
+ 增加支持长按热键，热键定义键数4次以上认为是长按绑定定义 @leexioua-keybinding.ahk 用例: LButton+n n n n => open(notepad)
+ open(cmd)/funcCmd(cmd)增加支持用户输入参数{%p}与剪贴板文本{%c}，例: http://www.google.com/search?q={%p}
+ open(cmd) 增强扩展其功能，调用Run失败会再尝试调用funcCmd方法
+ 增强 funcCmd（cmd)  热键可支持执行多个函数 用例：r r@notepad.exe => alert(123);info(1334);alert(333)
+ 增加 holdingLBtnAfterAction(key, enable)， 用于控制是否在执行动作后释放{LButton up} 用例: holdingLBtnAfterAction("1@explorer.exe", true)
+ 增加插件 plugin-configbak 用于备份个人使用软件的相关配置文件
+ 增加 ctrl+e e => eudic
+ 引入日志模块，方便问题定位
* 优化修改击键弹起触发热键, 即按键释放时触发
* 优化当只有单个按键热键，不需要等待下一次按键判断，单键热键动作无延时 用例: ^d@sublime_text.exe => send(^+k)
* 优化扩展相关动作参数，无参数时使用复制选择内容/剪贴板内容 例: eudicQuery(word:="") @ leexioua-actions.ahk
* 清理可简单使用funcCmd()实现的方法 @leexioua-actions.ahk 例: keymapping() => edit(%Help_keymappings%)
* 增加依赖到脚本目录下的Lib  Acc.ahk, Anchor.ahk
* 修正funcCmd（cmd)参数解析问题
* LButton+r => openOrRun 优化支持环境变量, 用户输入参数

## 20230314: 1.0.8
+ 配置参数名称优化， 统一使用getCfgValue()
+ 验证已支持组合键扩展 (Ctrl+c c) 用例：$^o $^o => SafeActivate(%eudic%)
+ 相关插件注册热键改用bindHotKey()
* 修正bindHotkey不支持LButton+w w问题
* 键映射调整，参考 leexioua-shortcuts-ahk.xlsx
* 修正WinActive title参数错误 用例：r r@notepad.exe => alert(123)

## 20230307: 1.0.7
+ 增加热键 ` => ALTRun `` => clQBar@CapsLock+
+ 支持同一热键在不同应用中执行不同的动作  LButton+f f@sublime_text.exe => findIt, LButton+f f@notepad.exe => alert(123)
+ 动作支持变量, 系统环境变量 或配置项的值 例: SafeActivate(%Path_eudic%)", eudicQuery(%clipboard%)
+ 支持Esc+单键，双键与三键，等同LButton键组合, Esc+f =>LButton+f
* 重构 keybinding, 将plugin-keymapping 合并
* 修正绑定单键热键时，字符输入失效问题 1 1 =>  open(notepad)
* 修正插件与keybinding插件热键注册冲突问题

## 20230303: 1.0.6
* 重写配置加载模块，启动时动态加载配置， 简化了新增参数需要使用的代码行
* 部分键绑定调整 leexioua-keys-keymappings.ahk
* 其它优化增强

## 20230221: 1.0.5-beta
+ keymapping配置支持使用含参数的方法调用 例：open(notepad.exe), edit(D:\ProgramxFiles\MouseInc\MouseInc.json)
+ 新增公共方法供keymapping配置使用，打开程序/文档/网址 open(cmd), 文本打开编辑文件 edit(filename) 
+ 增加keepass插件，功能检查并确保keepass已打开运行
* 修复SafeActivate() 等待窗口打开后发送按键功能
* CapsLock+单键 绑定带参数的方法错误, 例 LButton+x => open(xxx) 
* 取消 CapsLock+单键 => LButton+单键功能，预留CapsLock 作其它用途
* 改写标签方式的应用的热键功能实现，修改为插件方式实现
* 提高发送按键的层级优先级，确保外部ahk应用热键可接收到
* 修正由于插件加载顺序引起keymapping不能注册成功
* 按键名称转义发送效率优化 escKeys4Send(A_ThisHotkey)
* 增加markdown快速标记复选框完成状态 暂使用 LButton+x x => @sublime text

## 20230214: 1.0.4
+ 新增插件简化热键配置 plugin-keymapping.ahk ，如: LButton+e e
* 修改资源管理器文件对话框中热键 Ctrl+Q (快速跳转Quick)
* 其它优化， 复制文本预处理使用统一方法

## 20230210: 1.0.3-beta
+ 新增配置项集中管理 leexioua-ahk.ini
+ 新增ahk-cmd.ahk 动态ahk脚本发送到AltRun
+ 新增资源管理器文件对话框中 Ctrl+Alt+D 快速跳转到当前活动的目录

## 20230208: 1.0.2
+ 新增知乎搜索 LButton+z
+ 新增searchAhkSource - F8双键
+ 新增LButton+Tab -> Alt+Tab 切换窗口 @leexioua-lbl-global.ahk
+ 新增打开查看leexioua-shortcuts-ahk.xlsx (快捷键帮助), LButton+F1
+ 新增保存资源管理器剪贴板文本到文件 readme@leexioua.md @leexioua-lbl-explorer.ahk - 需要资源管理器选项设置 在标题栏中显示完整路径
+ 新增格式刷热键 Ctrl+Shift+c @leexioua-lbl-excel.ahk
+ 新增everything-cmd, evernote-cmd, mail-cmd 搜索关键词发送到AltRun， ahk-func中方法发送到AltRun
* leexioua-actions 修改相关方法名称

## 20230203: 1.0.1
* 修正viewAhkFile 路径拼接错误
* 修正plugin-keysfunc调用异常，键失效问题
* 修正plugin-keysfunc countKeys SetTimeout 偶尔绑定失败后，键失效问题
+ 新增 copyTitleText， copyTitleTextLine for LButton+t t

## 20230127: 1.0
+ 代码重新整理，模块化，规范代码，按功能和应用结构分享代码；插件加载方式方便根据需要修改加载
+ 增加多键热键支持，扩展更多可定义的热键  LButton+多键 （单键，双键，三键）
+ 热键键定义整理集中管理，方便维护 leexioua-keys-*.ahk, leexioua-lbl-*.ahk
+ 增加MACC支持，依赖Acc.ahk, Ankor.ahk  增加ADC新增任务的功能

